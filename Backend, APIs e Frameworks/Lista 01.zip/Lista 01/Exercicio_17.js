const CONVERT_KG_TO_G = 1000;

let kiloWeight = prompt("DIGITE SEU PESO ATUAL EM KG: ");

let gramWeight = kiloWeight * CONVERT_KG_TO_G;
alert(`O PESO DE ${kiloWeight}Kg EQUIVALE A ${gramWeight}g`);


