let basicSalary = prompt("DIGITE O VALOR ATUAL DO SALARIO MINIMO: ");

let currentSalary = prompt("DIGITE O VALOR BRUTO DO SEU SALARIO: ");

let amountBigger = currentSalary / basicSalary;
alert(`ATUALMENTE, VOCE RECEBE ${amountBigger} SALARIOS MINIMOS`);
