let first = prompt("DIGITE O PRIMEIRO NUMERO: ");

let second = prompt("DIGITE O SEGUNDO NUMERO: ");

let result = first / second;
alert(`${first} / ${second} = ${result}`);
