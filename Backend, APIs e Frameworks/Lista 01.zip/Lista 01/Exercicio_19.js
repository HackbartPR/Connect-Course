let base = prompt("DIGITE O TAMANHO, EM METROS, DE UM LADO DO QUADRADO: ");

let area = base * base;
alert(`A AREA DO QUADRADO E DE ${area} METROS QUADRADOS`);