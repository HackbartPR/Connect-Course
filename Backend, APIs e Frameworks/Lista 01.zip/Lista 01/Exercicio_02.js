let celsius = prompt("DIGITE A TEMPERATURA EM GRAUS CELSIUS: ");

let fahrenheit = (celsius * 1.8) + 32;
alert(`${celsius} CELSIUS E EQUIVALENTE A ${fahrenheit} FAHRENHEIT`);
