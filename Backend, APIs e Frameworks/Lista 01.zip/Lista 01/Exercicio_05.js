const WOOL_NEEDED_BY_SHIRT = 68;

let amountShirt = prompt("DIGITE A QUANTIDADE DE BLUSAS QUE DESEJA PRODUZIR: ");

let totalWoolNeeded = amountShirt * WOOL_NEEDED_BY_SHIRT;

alert(`PARA PRODUZIR ${amountShirt} BLUSAS, SERA NECESSARIO ${totalWoolNeeded} NOVELOS DE LA`);


