let first = prompt("DIGITE O PRIMEIRO NUMERO: ");

let second = prompt("DIGITE O SEGUNDO NUMERO: ");

let third = prompt("DIGITE O TERCEIRO NUMERO: ");

let result = first * second * third;
alert(`${first} x ${second} x ${third} = ${result}`);
